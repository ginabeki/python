#variables
x = 5
y = 8
print(x + y)
#result
13